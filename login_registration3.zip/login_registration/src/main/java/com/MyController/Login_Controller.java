package com.MyController;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


import com.entity.*;
@Controller
public class Login_Controller {
	
	
	@RequestMapping("login")
	public String login() {
		return "login";
	}
	
	

	@RequestMapping("register")
	public String register() {
		return "register";
	}
	
	@RequestMapping("admin")
	public String admin() {
		return "admin";
	}
	
	
	
	
	@Autowired
	SessionFactory sf;
	
	@RequestMapping("valid")
	ModelAndView valid(String name,String password) {
		ModelAndView modelandview=new ModelAndView();
		
		Session session=sf.openSession();
		
		Users userfromdb=session.get(Users.class,name );
		
		if(userfromdb==null) {
			
			modelandview.setViewName("login");
			modelandview.addObject("message", "invalid username");
			
		}
		
		else if(userfromdb.getPassword().equals(password)) {
		
			modelandview.setViewName("welcome");
			modelandview.addObject("name",name);
		}
		

		else {
			modelandview.setViewName("login");
			modelandview.addObject("message", "invalid password");
		}
		return modelandview;
	}
	
	@RequestMapping("saveUserData")
	
	public ModelAndView saveUserData(Users userfrombrowser)
	{
		ModelAndView modelandview=new ModelAndView();
		Session session=sf.openSession();

		Transaction tx=session.beginTransaction();
		
		session.save(userfrombrowser);
		
		tx.commit();
		
		modelandview.setViewName("login");
		modelandview.addObject("message", "registraction successfully please login");
		
		
		return modelandview;
	}
	
	
	@RequestMapping("admin1")
	public ModelAndView admin1(HttpServletRequest request)
	{
		ModelAndView modelandview=new ModelAndView();
		HttpSession httpsession=request.getSession();
		HashMap<Integer,Users> hashmap=(HashMap<Integer, Users>) httpsession.getAttribute("Users");
		
		Collection<Users> collection=hashmap.values();
	
		for(Users user:collection) {
			System.out.println(user);
		}
	
		return modelandview;
	}
	@RequestMapping("allData")
	ModelAndView allData(String name,String password) {
		ModelAndView modelandview=new ModelAndView();
		
		if(name.equals("admin")&& password.equals("admin") ) {
			
			modelandview.setViewName("admin");
			modelandview.addObject("message", "all records");
		}
		
		return modelandview;
			
		}
	
}

